/******************************************************************************
 *######################################################################
 *#    ______ ____  ____ ______   ____  __  ______  __________         #
 *#   / ____// __ \\/  _// ____/  / __ \\/ / / / __ \\/_  __/ __ \\    #
 *#  / __/  / /_/ / / / / /      / /_/ / /_/ / / / / / / / / / /       #
 *# / /___ / _, _/_/ / / /___   / ____/ __  / /_/ / / / / /_/ /        #
 *#/_____//_/ |_|/___/ \\____/  /_/   /_/ /_/\\____/ /_/  \\____/      #
 *#                                                                    #
 *######################################################################
 *
 * AdaptiveCoreProtectedStretch.js
 * Adaptive Core-Protected Stretch Script
 * Version: 1.0.0
 * Author: Eric
 *
 * An intelligent stretching tool specially designed for high dynamic range targets.
 * Enhances dark details while effectively protecting bright core regions from overexposure.
 *
 * ACKNOWLEDGEMENTS:
 * This script incorporates the Statistical Stretch algorithm originally developed by
 * Franklin Marek (www.setiastro.com). We are deeply grateful for his pioneering work
 * in astronomical image processing and for making his algorithm available to the community.
 *
 * Statistical Stretch Algorithm:
 * © 2024 Franklin Marek
 * Licensed under Creative Commons Attribution-NonCommercial 4.0 International License
 * Website: www.setiastro.com
 *
 * COPYRIGHT © 2025 Eric. ALL RIGHTS RESERVED.
 ******************************************************************************/

#feature-id    Script : EricPhoto > AdaptiveCoreProtectedStretch

#feature-info  Adaptive Core-Protected Stretch Tool<br/>\
<br/>\
An intelligent stretching tool designed for high dynamic range astronomical targets.<br/>\
<br/>\
Features:<br/>\
* Smart protection for bright core regions<br/>\
* Powerful dark detail enhancement<br/>\
* Maintains color fidelity<br/>\
* Multiple stretching algorithms<br/>\
<br/>\
Best for:<br/>\
* M42 Orion Nebula<br/>\
* NGC7023 Iris Nebula<br/>\
* M31 Andromeda Galaxy<br/>\
* Other high dynamic range targets<br/>\
<br/>\
Author: Eric

#define VERSION "1.0.0"
#define TITLE "Adaptive Core-Protected Stretch"

// 包含库文件
#include "lib/ACPSEngine.jsh"

// 包含 UI 库
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>

/**
 * ACPS 对话框
 */
function ACPSDialog() {
    this.__base__ = Dialog;
    this.__base__();

    // 创建引擎实例
    this.engine = new ACPSEngine();

    // 目标视图
    this.targetView = null;

    // 窗口标题
    this.windowTitle = TITLE + " v" + VERSION;
    this.userResizable = false;

    //
    // 帮助标签
    //
    this.helpLabel = new Label(this);
    this.helpLabel.frameStyle = FrameStyle_Box;
    this.helpLabel.margin = 4;
    this.helpLabel.wordWrapping = true;
    this.helpLabel.useRichText = true;
    this.helpLabel.text = "<p><b>" + TITLE + " v" + VERSION + "</b></p>" +
        "<p>智能拉伸工具，特别适合高动态范围天体目标。也可用作对星点拉伸的保护避免过渡曝光</p>" +
        "<p>作者：Eric</p>" +
        "<p>使用方法：</p>" +
        "<ol>" +
        "<li>选择目标图像</li>" +
        "<li>调整拉伸强度和保护参数（正常情况下使用默认参数即可）</li>" +
        "<li>点击应用按钮</li>" +
        "<li>一键模式包含Hybrid模式，无需而外再使用</li>" +
        "</ol>";

    //
    // 目标图像选择
    //
    this.targetImage_Label = new Label(this);
    this.targetImage_Label.text = "目标图像：";
    this.targetImage_Label.textAlignment = TextAlign_Right | TextAlign_VertCenter;
    this.targetImage_Label.minWidth = 120;

    this.targetImage_ViewList = new ViewList(this);
    this.targetImage_ViewList.getAll();
    this.targetImage_ViewList.minWidth = 300;
    this.targetImage_ViewList.toolTip = "<p>选择要处理的图像。</p>";
    this.targetImage_ViewList.onViewSelected = function(view) {
        this.dialog.targetView = view;
    };

    // 默认选择当前活动窗口
    if (ImageWindow.activeWindow && !ImageWindow.activeWindow.isNull) {
        this.targetView = ImageWindow.activeWindow.mainView;
        this.targetImage_ViewList.currentView = this.targetView;
    }

    this.targetImage_Sizer = new HorizontalSizer;
    this.targetImage_Sizer.spacing = 4;
    this.targetImage_Sizer.add(this.targetImage_Label);
    this.targetImage_Sizer.add(this.targetImage_ViewList, 100);

    //
    // 算法选择区域
    //
    this.method_GroupBox = new GroupBox(this);
    this.method_GroupBox.title = "拉伸算法";
    this.method_GroupBox.sizer = new VerticalSizer;
    this.method_GroupBox.sizer.margin = 6;
    this.method_GroupBox.sizer.spacing = 4;

    this.statistical_Radio = new RadioButton(this);
    this.statistical_Radio.text = "Statistical Stretch（正常情况推荐使用，高光保护请使用Hybrid模式）";
    this.statistical_Radio.checked = (this.engine.parameters.stretchMethod == "statistical");
    this.statistical_Radio.toolTip = "<p><b>Statistical Stretch（纯净版）</b></p>" +
        "<p>基于统计学的拉伸算法，纯粹的数学拉伸。</p>" +
        "<p>优点：</p>" +
        "<ul>" +
        "<li>数学保证收敛到目标中值</li>" +
        "<li>纯净拉伸，无保护参数干扰</li>" +
        "<li>迭代收敛，结果可预测</li>" +
        "<li>不使用遮罩和保护参数</li>" +
        "</ul>";
    this.statistical_Radio.onCheck = function(checked) {
        if (checked) {
            this.dialog.engine.parameters.stretchMethod = "statistical";
            this.dialog.updateControlsState();
        }
    };

    this.hybrid_Radio = new RadioButton(this);
    this.hybrid_Radio.text = "Hybrid（高光保护）";
    this.hybrid_Radio.checked = (this.engine.parameters.stretchMethod == "hybrid");
    this.hybrid_Radio.toolTip = "<p><b>混合拉伸算法</b></p>" +
        "<p>结合 Arcsinh 和暗部增强的混合算法。</p>" +
        "<p>优点：</p>" +
        "<ul>" +
        "<li>暗部增强强力</li>" +
        "<li>使用遮罩保护高光区域</li>" +
        "<li>支持核心保护参数调节</li>" +
        "<li>适合极暗图像</li>" +
        "</ul>" +
        "<p>注意：需要手动调节拉伸强度和保护参数</p>";
    this.hybrid_Radio.onCheck = function(checked) {
        if (checked) {
            this.dialog.engine.parameters.stretchMethod = "hybrid";
            this.dialog.updateControlsState();
        }
    };

    this.superAuto_Radio = new RadioButton(this);
    this.superAuto_Radio.text = "一键自动拉伸模式（全自动保护高光）";
    this.superAuto_Radio.checked = (this.engine.parameters.stretchMethod == "superauto");
    this.superAuto_Radio.toolTip = "<p><b>超级一键模式</b></p>" +
        "<p>自动执行完整的三步拉伸流程：</p>" +
        "<ol>" +
        "<li><b>第一步：Hybrid 预拉伸</b><br/>使用混合算法进行初步拉伸</li>" +
        "<li><b>第二步：Statistical Stretch</b><br/>精确拉伸到目标中值 0.25</li>" +
        "<li><b>第三步：直方图变换</b><br/>自动调整黑点和中间调</li>" +
        "</ol>" +
        "<p>适合：快速处理，一键完成全部拉伸</p>" +
        "<p>注意：所有参数将被自动设置，无需手动调节</p>";
    this.superAuto_Radio.onCheck = function(checked) {
        if (checked) {
            this.dialog.engine.parameters.stretchMethod = "superauto";
            this.dialog.updateControlsState();
        }
    };

    this.method_GroupBox.sizer.add(this.statistical_Radio);
    this.method_GroupBox.sizer.add(this.hybrid_Radio);
    this.method_GroupBox.sizer.add(this.superAuto_Radio);

    //
    // 拉伸参数区域
    //
    this.stretchParams_GroupBox = new GroupBox(this);
    this.stretchParams_GroupBox.title = "拉伸参数";
    this.stretchParams_GroupBox.sizer = new VerticalSizer;
    this.stretchParams_GroupBox.sizer.margin = 6;
    this.stretchParams_GroupBox.sizer.spacing = 4;

    // 拉伸强度
    this.stretchStrength_Control = new NumericControl(this);
    this.stretchStrength_Control.label.text = "拉伸强度：";
    this.stretchStrength_Control.label.minWidth = 120;
    this.stretchStrength_Control.setRange(0.0, 1.0);
    this.stretchStrength_Control.slider.setRange(0, 100);
    this.stretchStrength_Control.slider.minWidth = 300;
    this.stretchStrength_Control.setPrecision(2);
    this.stretchStrength_Control.setValue(this.engine.parameters.stretchStrength);
    this.stretchStrength_Control.toolTip = "<p>拉伸强度：控制整体拉伸的强度。</p>" +
        "<p>• 低值（0.2-0.4）：轻度拉伸</p>" +
        "<p>• 中值（0.4-0.6）：标准拉伸</p>" +
        "<p>• 高值（0.6-0.9）：强力拉伸</p>";
    this.stretchStrength_Control.onValueUpdated = function(value) {
        this.dialog.engine.parameters.stretchStrength = value;
    };

    // 目标中值
    this.targetMedian_Control = new NumericControl(this);
    this.targetMedian_Control.label.text = "目标中值：";
    this.targetMedian_Control.label.minWidth = 120;
    this.targetMedian_Control.setRange(0.05, 0.3);
    this.targetMedian_Control.slider.setRange(0, 100);
    this.targetMedian_Control.slider.minWidth = 300;
    this.targetMedian_Control.setPrecision(3);
    this.targetMedian_Control.setValue(this.engine.parameters.targetMedian);
    this.targetMedian_Control.toolTip = "<p>目标中值：预拉伸的目标亮度。</p>" +
        "<p>此参数用于统一不同图像的起始亮度，确保拉伸效果一致。</p>" +
        "<p>• 0.05-0.10：保守值（适合已经较亮的图像）</p>" +
        "<p>• 0.10-0.15：标准值（推荐）</p>" +
        "<p>• 0.15-0.25：较高值（适合极暗图像）</p>";
    this.targetMedian_Control.onValueUpdated = function(value) {
        this.dialog.engine.parameters.targetMedian = value;
    };

    // 迭代次数
    this.maxIterations_Control = new NumericControl(this);
    this.maxIterations_Control.label.text = "迭代次数：";
    this.maxIterations_Control.label.minWidth = 120;
    this.maxIterations_Control.setRange(1, 5);
    this.maxIterations_Control.slider.setRange(0, 100);
    this.maxIterations_Control.slider.minWidth = 300;
    this.maxIterations_Control.setPrecision(0);
    this.maxIterations_Control.setValue(this.engine.parameters.maxIterations);
    this.maxIterations_Control.toolTip = "<p>最大迭代次数：自动迭代直到收敛到目标中值。</p>" +
        "<p>• 1次：快速处理，可能不够精确</p>" +
        "<p>• 2-3次：推荐值，平衡速度和精度</p>" +
        "<p>• 4-5次：最高精度，处理时间较长</p>";
    this.maxIterations_Control.onValueUpdated = function(value) {
        this.dialog.engine.parameters.maxIterations = Math.round(value);
    };

    this.stretchParams_GroupBox.sizer.add(this.stretchStrength_Control);
    this.stretchParams_GroupBox.sizer.add(this.targetMedian_Control);
    this.stretchParams_GroupBox.sizer.add(this.maxIterations_Control);

    //
    // 核心保护区域
    //
    this.protection_GroupBox = new GroupBox(this);
    this.protection_GroupBox.title = "核心保护（仅 Hybrid 方法）";
    this.protection_GroupBox.sizer = new VerticalSizer;
    this.protection_GroupBox.sizer.margin = 6;
    this.protection_GroupBox.sizer.spacing = 4;

    // 保护强度
    this.coreProtection_Control = new NumericControl(this);
    this.coreProtection_Control.label.text = "保护强度：";
    this.coreProtection_Control.label.minWidth = 120;
    this.coreProtection_Control.setRange(0.0, 1.0);
    this.coreProtection_Control.slider.setRange(0, 100);
    this.coreProtection_Control.slider.minWidth = 300;
    this.coreProtection_Control.setPrecision(2);
    this.coreProtection_Control.setValue(this.engine.parameters.coreProtection);
    this.coreProtection_Control.toolTip = "<p>核心保护强度：保护亮核心的力度。</p>" +
        "<p>• 0.0：无保护</p>" +
        "<p>• 0.5-0.7：中等保护</p>" +
        "<p>• 0.8-1.0：强力保护（推荐用于高光比目标）</p>";
    this.coreProtection_Control.onValueUpdated = function(value) {
        this.dialog.engine.parameters.coreProtection = value;
    };

    // 保护阈值
    this.protectionThreshold_Control = new NumericControl(this);
    this.protectionThreshold_Control.label.text = "保护阈值：";
    this.protectionThreshold_Control.label.minWidth = 120;
    this.protectionThreshold_Control.setRange(0.0, 1.0);
    this.protectionThreshold_Control.slider.setRange(0, 100);
    this.protectionThreshold_Control.slider.minWidth = 300;
    this.protectionThreshold_Control.setPrecision(2);
    this.protectionThreshold_Control.setValue(this.engine.parameters.protectionThreshold);
    this.protectionThreshold_Control.toolTip = "<p>保护阈值：高于此亮度的区域将被保护。</p>" +
        "<p>• 0.6-0.7：保护极亮区域</p>" +
        "<p>• 0.7-0.8：标准值</p>" +
        "<p>• 0.8-0.9：保护较大范围</p>";
    this.protectionThreshold_Control.onValueUpdated = function(value) {
        this.dialog.engine.parameters.protectionThreshold = value;
    };

    // 平滑度
    this.protectionSmoothness_Control = new NumericControl(this);
    this.protectionSmoothness_Control.label.text = "过渡平滑：";
    this.protectionSmoothness_Control.label.minWidth = 120;
    this.protectionSmoothness_Control.setRange(0.0, 1.0);
    this.protectionSmoothness_Control.slider.setRange(0, 100);
    this.protectionSmoothness_Control.slider.minWidth = 300;
    this.protectionSmoothness_Control.setPrecision(2);
    this.protectionSmoothness_Control.setValue(this.engine.parameters.protectionSmoothness);
    this.protectionSmoothness_Control.toolTip = "<p>平滑度：保护过渡的平滑程度。</p>" +
        "<p>• 低值：锐利过渡</p>" +
        "<p>• 高值：柔和过渡</p>";
    this.protectionSmoothness_Control.onValueUpdated = function(value) {
        this.dialog.engine.parameters.protectionSmoothness = value;
    };

    this.protection_GroupBox.sizer.add(this.coreProtection_Control);
    this.protection_GroupBox.sizer.add(this.protectionThreshold_Control);
    this.protection_GroupBox.sizer.add(this.protectionSmoothness_Control);


    //
    // 按钮
    //
    this.newInstance_Button = new ToolButton(this);
    this.newInstance_Button.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstance_Button.setScaledFixedSize(20, 20);
    this.newInstance_Button.toolTip = "创建脚本实例";
    this.newInstance_Button.onMousePress = function() {
        this.hasFocus = true;
        this.dialog.engine.saveParameters();
        this.dialog.newInstance();
    };

    this.ok_Button = new PushButton(this);
    this.ok_Button.text = "应用";
    this.ok_Button.icon = this.scaledResource(":/icons/ok.png");
    this.ok_Button.onClick = function() {
        this.dialog.applyStretch();
    };

    this.cancel_Button = new PushButton(this);
    this.cancel_Button.text = "取消";
    this.cancel_Button.icon = this.scaledResource(":/icons/cancel.png");
    this.cancel_Button.onClick = function() {
        this.dialog.cancel();
    };

    this.buttons_Sizer = new HorizontalSizer;
    this.buttons_Sizer.spacing = 6;
    this.buttons_Sizer.add(this.newInstance_Button);
    this.buttons_Sizer.addStretch();
    this.buttons_Sizer.add(this.ok_Button);
    this.buttons_Sizer.add(this.cancel_Button);

    //
    // 主布局
    //
    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 6;
    this.sizer.add(this.helpLabel);
    this.sizer.add(this.targetImage_Sizer);
    this.sizer.add(this.method_GroupBox);
    this.sizer.add(this.stretchParams_GroupBox);
    this.sizer.add(this.protection_GroupBox);
    this.sizer.addSpacing(4);
    this.sizer.add(this.buttons_Sizer);

    //
    // 事件处理方法
    //

    /**
     * 更新控件启用状态
     */
    this.updateControlsState = function() {
        var method = this.engine.parameters.stretchMethod;
        var isHybrid = (method === "hybrid");
        var isSuperAuto = (method === "superauto");

        // 拉伸强度只对 Hybrid 方法有效
        this.stretchStrength_Control.enabled = isHybrid;

        // 核心保护参数只对 Hybrid 方法有效
        this.coreProtection_Control.enabled = isHybrid;
        this.protectionThreshold_Control.enabled = isHybrid;
        this.protectionSmoothness_Control.enabled = isHybrid;

        // 目标中值和迭代次数：超级一键模式下禁用（自动设置）
        this.targetMedian_Control.enabled = !isSuperAuto;
        this.maxIterations_Control.enabled = !isSuperAuto;
    };

    this.adjustToContents();
    this.setFixedSize();

    // 初始化控件状态
    this.updateControlsState();

    /**
     * 应用拉伸
     */
    this.applyStretch = function() {
        if (!this.targetView) {
            var msgBox = new MessageBox(
                "请先选择一个目标图像。",
                TITLE,
                StdIcon_Error,
                StdButton_Ok
            );
            msgBox.execute();
            return;
        }

        try {
            Console.writeln("\n" + "=".repeat(60));
            Console.writeln("开始拉伸处理");
            Console.writeln("=".repeat(60));

            // 执行处理
            this.engine.process(this.targetView);

            Console.writeln("\n" + "=".repeat(60));
            Console.writeln("拉伸处理完成！");
            Console.writeln("=".repeat(60));

            // 保存参数
            this.engine.saveParameters();

            // 关闭对话框
            this.ok();

        } catch (error) {
            Console.criticalln("\n" + "=".repeat(60));
            Console.criticalln("拉伸失败！");
            Console.criticalln("错误：" + error.message);
            Console.criticalln("=".repeat(60));

            var msgBox = new MessageBox(
                "拉伸处理失败：\n\n" + error.message + "\n\n请检查控制台输出以获取详细信息。",
                TITLE,
                StdIcon_Error,
                StdButton_Ok
            );
            msgBox.execute();
        }
    };
}

ACPSDialog.prototype = new Dialog;

/**
 * 主函数
 */
function main() {
    Console.writeln("\n" + "=".repeat(60));
    Console.writeln(TITLE + " v" + VERSION);
    Console.writeln("=".repeat(60));

    // 检查执行模式
    if (Parameters.isViewTarget) {
        // 视图模式 - 静默执行
        Console.writeln("执行模式：视图目标");

        var engine = new ACPSEngine();
        engine.loadParameters();
        engine.process(Parameters.targetView);

    } else if (Parameters.isGlobalTarget) {
        // 全局模式 - 静默执行
        Console.writeln("执行模式：全局");

        var engine = new ACPSEngine();
        engine.loadParameters();

        // 处理所有打开的图像
        var windows = ImageWindow.windows;
        Console.writeln("正在处理 ", windows.length, " 个图像...");

        for (var i = 0; i < windows.length; i++) {
            Console.writeln("\n正在处理图像 ", i + 1, " / ", windows.length);
            try {
                engine.process(windows[i].mainView);
            } catch (error) {
                Console.criticalln("处理失败 ", windows[i].mainView.id, "：", error.message);
            }
        }

    } else {
        // 直接模式 - 显示 GUI
        Console.writeln("执行模式：直接（图形界面）");

        var dialog = new ACPSDialog();
        dialog.execute();
    }

    Console.writeln("\n" + "=".repeat(60));
    Console.writeln("脚本执行完成");
    Console.writeln("=".repeat(60) + "\n");
}

// 执行主函数
main();